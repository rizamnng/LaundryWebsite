from django.contrib import admin

# Register your models here.
from .models import StaffInfo, Price
admin.site.register(StaffInfo)
admin.site.register(Price)
