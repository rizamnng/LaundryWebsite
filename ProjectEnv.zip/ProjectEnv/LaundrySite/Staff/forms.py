from django import forms

class StaffInfoForm(forms.Form):
    first_name = forms.CharField( required = True, widget=forms.TextInput(attrs={'class': 'form-control'}))
    middle_name = forms.CharField(required = False, widget=forms.TextInput(attrs={'class': 'form-control'}))
    last_name = forms.CharField(required = True, widget=forms.TextInput(attrs={'class': 'form-control'}))
    contact_number = forms.CharField(required = True, widget=forms.TextInput(attrs={'class': 'form-control'}))
    email = forms.EmailField(required = True, widget=forms.TextInput(attrs={'class': 'form-control'}))
    address = forms.CharField(required = True, widget=forms.TextInput(attrs={'class': 'form-control'}))
    username= forms.CharField(required = True, widget=forms.TextInput(attrs={'class': 'form-control'}))
    password = forms.CharField(widget=forms.PasswordInput(attrs={'class': 'form-control'}), required = True)
    confirm_password = forms.CharField(widget=forms.PasswordInput(attrs={'class': 'form-control'}), required = True)

class FoldPriceForm(forms.Form):
    Fregular= forms.DecimalField(label = 'Regular Clothes ', required = True, widget=forms.NumberInput(attrs={'class': 'form-control'}))
    Fdenims = forms.DecimalField(label = "Denim Clothes ", required = True, widget=forms.NumberInput(attrs={'class': 'form-control'}))
    FcurTableBed = forms.DecimalField(label = "Curtins/ Table Cloth/ Beddings ", required = True, widget=forms.NumberInput(attrs={'class': 'form-control'}))
    FcomfSlbagBla = forms.DecimalField(label = "Comforters/ Sleeping Bag/ Blankets ", required = True, widget=forms.NumberInput(attrs={'class': 'form-control'}))
    FtoweLines = forms.DecimalField(label = "Towels/ Lines ", required = True, widget=forms.NumberInput(attrs={'class': 'form-control'}))

class PressPriceForm(forms.Form):
    Pregular= forms.DecimalField(label = 'Regular Clothes ', required = True, widget=forms.NumberInput(attrs={'class': 'form-control'}))
    Pdenims = forms.DecimalField(label = "Denim Clothes ", required = True, widget=forms.NumberInput(attrs={'class': 'form-control'}))
    PcurTableBed = forms.DecimalField(label = "Curtins/ Table Cloth/ Beddings ", required = True, widget=forms.NumberInput(attrs={'class': 'form-control'}))
    PcomfSlbagBla = forms.DecimalField(label = "Comforters/ Sleeping Bag/ Blankets ", required = True, widget=forms.NumberInput(attrs={'class': 'form-control'}))
    PtoweLines = forms.DecimalField(label = "Towels/ Lines ", required = True, widget=forms.NumberInput(attrs={'class': 'form-control'}))

class WeighForm(forms.Form):
    regular= forms.DecimalField(label = 'Regular Clothes ', required = True, initial=0, widget=forms.NumberInput(attrs={'class': 'form-control'}))
    denims = forms.DecimalField(label = "Denim Clothes ", required = True, initial=0, widget=forms.NumberInput(attrs={'class': 'form-control'}))
    curTableBed = forms.DecimalField(label = "Curtins/ Table Cloth/ Beddings ", required = True, initial=0, widget=forms.NumberInput(attrs={'class': 'form-control'}))
    comfSlbagBla = forms.DecimalField(label = "Comforters/ Sleeping Bag/ Blankets ", required = True, initial=0, widget=forms.NumberInput(attrs={'class': 'form-control'}))
    toweLines = forms.DecimalField(label = "Towels/ Lines ", required = True, initial=0, widget=forms.NumberInput(attrs={'class': 'form-control'}))
