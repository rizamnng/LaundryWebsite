from django.shortcuts import render, redirect, get_object_or_404
from django.contrib.auth.models import User
from django.contrib.auth import logout
from django.http import HttpResponse, HttpResponseRedirect
from django import forms
from django.contrib.auth.forms import UserCreationForm, AuthenticationForm
from django.contrib import messages
from django. contrib. auth import authenticate, login
from clientInfo.models import ClientInfo
from transactions.models import Item, Notification
from transactions.forms import TransactionForm
from Staff.models import Price, StaffInfo
from django.core.exceptions import ValidationError
from django.http import HttpResponse, Http404
from django.contrib import messages
from .forms import StaffInfoForm, FoldPriceForm, PressPriceForm, WeighForm
# Create your views here.
calendar={
    1: 'January',
    2: 'February',
    3: 'March',
    4: 'April',
    5: 'May',
    6: 'June',
    7: 'July',
    8: 'August',
    9: 'September',
    10: 'October',
    11: 'November',
    12: 'December'
}


def login_view(request):
    form = AuthenticationForm()
    if request.method == 'POST':
        form = AuthenticationForm(request=request, data=request.POST)
        if form.is_valid():
            username = form.cleaned_data.get('username')
            password = form.cleaned_data.get('password')
            user= User.objects.get(username=username)
            if user.is_staff:
                user = authenticate(username=username, password=password)
                if user is not None:
                    login(request, user)
                    return redirect(f'{username}/')
    return render(request = request,
                    template_name = "login.html",
                    context={"form":form})

def logOut_view(request, username):
    if request.user.is_authenticated:
        logout(request)
    return redirect('../../../')

def staffHomePage_view(request, username):
    if  (not request.user.is_authenticated or request.user.is_staff == False):
        return redirect('../../staff/')
    elif request.user.is_authenticated and username!=request.user.username:
        return HttpResponseRedirect(f'../{request.user}/')

    bookings= Item.objects.all()
    req= []
    for book in bookings:
        if book.totalBill == 0:
            req.append(book)
    context={
        'object': request.user,
        'info': req,
        }
    return render(request, "StaffHomePage.html",context)

def bookings_view(request,username):
    if  (not request.user.is_authenticated or request.user.is_staff == False):
        raise Http404
    elif request.user.is_authenticated:
        bookings= Item.objects.all()
        req= []
        for book in bookings:
            if book.totalBill == 0:
                req.append(book)
        context={
            'info': req,
            'object': request.user,
        }
    return render(request, 'requestBooking.html', context)

def acceptBooking_view(request, username,id):
    if  (not request.user.is_authenticated or request.user.is_staff == False):
        raise Http404
    elif request.user.is_authenticated:
        obj= get_object_or_404(Item, id= id)
        price=get_object_or_404(Price, id=1)
        weighForm = WeighForm (request.POST or None)
        if request.method == "POST":
            if weighForm.is_valid():
                reg= float(request.POST.get('regular'))
                jm= float(request.POST.get("denims"))
                ctb= float(request.POST.get('curTableBed'))
                cslb= float(request.POST.get('comfSlbagBla'))
                tl= float(request.POST.get('toweLines'))
                obj.regular= reg
                obj.jeans_maong= jm
                obj.curTableBed= ctb
                obj.comfSlbagBla= cslb
                obj.toweLines= tl
                if obj.type=='Wash-Dry-Fold':
                    reg_bill= (reg*float(price.FPr_regular))
                    jm_bill= (jm*float(price.FPr_jeans_maong))
                    ctb_bill= (ctb*float(price.FPr_curTableBed))
                    cslb_bill=(cslb*float(price.FPr_comfSlbagBla))
                    tl_bill=(tl*float(price.FPr_toweLines))
                    total= reg_bill+jm_bill+ctb_bill+cslb_bill+tl_bill
                else:
                    reg_bill= (reg*float(price.PPr_regular))
                    jm_bill= (jm*float(price.PPr_jeans_maong))
                    ctb_bill= (ctb*float(price.PPr_curTableBed))
                    cslb_bill=(cslb*float(price.PPr_comfSlbagBla))
                    tl_bill=(tl*float(price.PPr_toweLines))
                    total= reg_bill+jm_bill+ctb_bill+cslb_bill+tl_bill
                obj.totalBill= total
                obj.save()
                Notification.objects.create(
                    laundry_id = obj.id,
                    username = obj.username ,
                    message = 'Your bill has been computed',
                    incharge_staff = username,
                    reason = '',
                    read = False )
                return redirect('confirmed/')
            else:
                weighForm = WeighForm (request.POST or None)
        context={
            'item':obj,
            'weighForm' : weighForm
        }
    return render(request, "acceptBooking.html", context)

def accepted_view(request, username, id):
    if  (not request.user.is_authenticated or request.user.is_staff == False):
        raise Http404
    elif request.user.is_authenticated:
        item= get_object_or_404(Item, id= id)
        content={
            'info': item
        }
    return render(request, 'bookingConfirmation.html', content)

def deny_view(request,username, id):
    if  (not request.user.is_authenticated or request.user.is_staff == False):
        raise Http404
    elif request.user.is_authenticated:
        item= get_object_or_404(Item, id= id)
        if request.method == 'POST':
            _reason= request.POST.get('reason')
            _message= 'Your laundry has been denied.'
            Notification.objects.create(
                laundry_id = item.id,
                username = item.username ,
                message = _message,
                incharge_staff = username,
                reason = _reason,
                read = False )
            item.delete()
            return redirect('../../../')
        content={
            'info':item
        }
    return render(request, 'denybooking.html', content)

def onGoing_vew(request, username):
    if  (not request.user.is_authenticated or request.user.is_staff == False):
        raise Http404
    elif request.user.is_authenticated:
        bookings= Item.objects.all()
        on_going=[]
        for item in bookings:
            if item.totalBill != 0 and item.complete== False:
                on_going.append(item)
        content ={
            'item': on_going,
            'object': request.user,
        }
    return render(request, 'onGoing.html', content)

def information_view(request, username, id):
    if  (not request.user.is_authenticated or request.user.is_staff == False):
        raise Http404
    elif request.user.is_authenticated:
        item= get_object_or_404(Item, id= id)
        price=get_object_or_404(Price, id=1)
        _reg = item.regular
        _den = item.jeans_maong
        _ctb = item.curTableBed
        _cslb = item.comfSlbagBla
        _tl = item.toweLines
        if item.type == 'Wash-Dry-Fold':
            reg= _reg*price.FPr_regular
            den= _den*price.FPr_jeans_maong
            ctb= _ctb*price.FPr_curTableBed
            cslb= _cslb*price.FPr_comfSlbagBla
            tl= _tl*price.FPr_toweLines
        else:
            reg= _reg*price.PPr_regular
            den= _den*price.PPr_jeans_maong
            ctb= _ctb*price.PPr_curTableBed
            cslb= _cslb*price.PPr_comfSlbagBla
            tl= _tl*price.PPr_toweLines
        content={
            'info': item,
            'prices':{
                'preg':round(reg,2),
                'pden':round(den,2),
                'pctb':round(ctb,2),
                'pcslb':round(cslb,2),
                'ptl':round(tl,2)
            }
        }
    return render(request, 'information.html', content)

def done_view(request, username, id):
    if  (not request.user.is_authenticated or request.user.is_staff == False):
        raise Http404
    elif request.user.is_authenticated:
        item= get_object_or_404(Item, id= id)
        if request.method =="POST":
            _message='Your laundry are now clean, we will deliver it back to you today.'
            Notification.objects.create(
                laundry_id = item.id,
                username = item.username ,
                message = _message,
                incharge_staff = username,
                reason = '',
                read = False )
            item.complete= True
            item.save()
            return redirect('../../')

        content={
            'info': item,
            'object': request.user,
        }
    return render(request, 'done.html', content)

def laundryCleaned_view(request, username):
    if  (not request.user.is_authenticated or request.user.is_staff == False):
        raise Http404
    elif request.user.is_authenticated:
        laundries= Item.objects.all()
        done=[]
        for laundry in laundries:
            if laundry.complete == True and laundry.delivered== False:
                done.append(laundry)
        content={
            'info':done,
            'object': request.user,
        }
    return render(request, 'laundryCleaned.html', content)

def confirmDelivery_view(request, username, id):
    if  (not request.user.is_authenticated or request.user.is_staff == False):
        raise Http404
    elif request.user.is_authenticated:
        item = get_object_or_404(Item, id= id)
        if request.method == 'POST':
            item.delivered = True
            item.save()
            return redirect('../')
        content={
            'info':item
        }
    return render(request, 'confirmDelivery.html', content)

def history_view(request, username):
    if  (not request.user.is_authenticated or request.user.is_staff == False):
        raise Http404
    elif request.user.is_authenticated:
        laundries= Item.objects.all()
        history=[]
        for laundry in laundries:
            if laundry.complete == True and laundry.delivered== True:
                history.append(laundry)
        if request.method == 'POST':
            user = request.POST.get('username')
            return redirect(f'{user}/')
        content={
            'info': history,
            'object': request.user,
        }
    return render(request, 'bookinghistory.html', content)

def searchHistory_view(request, username, customer):
    if  (not request.user.is_authenticated or request.user.is_staff == False):
        raise Http404
    elif request.user.is_authenticated:
        laundries= Item.objects.all()
        history=[]
        payments=0
        count=0
        for laundry in laundries:
            if laundry.complete == True and laundry.username == customer:
                history.append(laundry)
                payments =payments + laundry.totalBill
                count+=1
        content ={
            'info': history,
            'bills': payments,
            'count': count,
            'name': customer,
            'object': request.user,
        }
    return render(request, 'searchHistory.html', content)

def searchUsernameDetails_view(request, username, customer , id):
    if  (not request.user.is_authenticated or request.user.is_staff == False):
        raise Http404
    elif request.user.is_authenticated:
        _item= get_object_or_404(Item, id=id)
        content={
            'info':_item
        }
    return render(request, 'historyDetails.html', content)

def historyDetails_view(request, username, id):
    if  (not request.user.is_authenticated or request.user.is_staff == False):
        raise Http404
    elif request.user.is_authenticated:
        _item= get_object_or_404(Item, id=id)
        content={
            'info':_item
        }
    return render(request, 'historyDetails.html', content)

def walkInTransactions_view(request, username):
    if  (not request.user.is_authenticated or request.user.is_staff == False):
        raise Http404
    elif request.user.is_authenticated:
        price=get_object_or_404(Price, id=1)
        name = username
        form = TransactionForm(request.POST or None)
        weighForm = WeighForm (request.POST or None)
        if request.method == 'POST':
            if form.is_valid() and weighForm.is_valid():
                _type = request.POST.get('type')
                if _type=='Wash-Dry-Fold':
                    reg_bill= float(request.POST.get('regular'))*float(price.FPr_regular)
                    jm_bill= float(request.POST.get('denims'))*float(price.FPr_jeans_maong)
                    ctb_bill= float(request.POST.get('curTableBed'))*float(price.FPr_curTableBed)
                    cslb_bill= float(request.POST.get('comfSlbagBla'))*float(price.FPr_comfSlbagBla)
                    tl_bill=float(request.POST.get('toweLines'))*float(price.FPr_toweLines)
                    total= reg_bill+jm_bill+ctb_bill+cslb_bill+tl_bill
                    _id= Item.objects.create(
                        first_name = request.POST.get('first_name'),
                        middle_name = request.POST.get('middle_name'),
                        last_name = request.POST.get('last_name'),
                        contact_number = request.POST.get('contact_number'),
                        email = request.POST.get('email'),
                        address = request.POST.get('address'),
                        specific_address = request.POST.get('specific_address'),
                        type = _type,
                        regular = request.POST.get('regular'),
                        jeans_maong = request.POST.get('denims'),
                        curTableBed = request.POST.get('curTableBed'),
                        comfSlbagBla = request.POST.get('comfSlbagBla'),
                        toweLines = request.POST.get('toweLines'),
                        getTime = '',
                        customerNote = request.POST.get('note'),
                        complete = False,
                        totalBill = total,
                        username = name,
                        delivered = False
                    ).id
                    return redirect(f"{_id}/")

                elif _type=='Wash-Dry-Press' :
                    reg_bill= float(request.POST.get('regular'))*float(price.PPr_regular)
                    jm_bill= float(request.POST.get('denims'))*float(price.PPr_jeans_maong)
                    ctb_bill= float(request.POST.get('curTableBed'))*float(price.PPr_curTableBed)
                    cslb_bill= float(request.POST.get('comfSlbagBla'))*float(price.PPr_comfSlbagBla)
                    tl_bill= float(request.POST.get('toweLines'))*float(price.PPr_toweLines)
                    total= reg_bill+jm_bill+ctb_bill+cslb_bill+tl_bill
                    _id= Item.objects.create(
                        first_name = request.POST.get('first_name'),
                        middle_name = request.POST.get('middle_name'),
                        last_name = request.POST.get('last_name'),
                        contact_number = request.POST.get('contact_number'),
                        email = request.POST.get('email'),
                        address = request.POST.get('address'),
                        specific_address = request.POST.get('specific_address'),
                        type = _type,
                        regular = request.POST.get('regular'),
                        jeans_maong = request.POST.get('denims'),
                        curTableBed = request.POST.get('curTableBed'),
                        comfSlbagBla = request.POST.get('comfSlbagBla'),
                        toweLines = request.POST.get('toweLines'),
                        getTime = '',
                        customerNote = request.POST.get('note'),
                        complete = False,
                        totalBill = total,
                        username = name,
                        delivered = False
                    ).id
                    return redirect(f"{_id}/")

                else:
                    messages.warning(request, 'Invalid input for Laundry type.')
            else:
                form = TransactionForm(request.POST or None)
                weighForm = WeighForm (request.POST or None)
        content={
            'infoForm': form,
            'weighForm': weighForm
        }
    return render(request, 'walkInTransactions.html', content)

def walkInConfirmation_view(request, username, id):
    if  (not request.user.is_authenticated or request.user.is_staff == False):
        raise Http404
    elif request.user.is_authenticated:
        item = get_object_or_404(Item, id =id )
        content={
            'info': item
        }
    return render(request,'walkInConfirmation.html', content)

def account_view(request, username):
    if  (not request.user.is_authenticated or request.user.is_staff == False):
        raise Http404
    elif request.user.is_authenticated:
        account= get_object_or_404(StaffInfo, username= username)
        content={
            'staff':account,
            'object': request.user,
        }
    return render(request, 'staffAccount.html', content )


def addStaff_view(request, username):
    if  (not request.user.is_authenticated or request.user.is_staff == False):
        raise Http404
    elif request.user.is_authenticated:
        name= username
        staffs = User.objects.all()
        usernames=[]
        for obj in staffs:
            usernames.append(obj.username)
        form = StaffInfoForm(request.POST or None)
        if request.method == 'POST':
            form = StaffInfoForm(request.POST)
            if form.is_valid():
                username = request.POST.get('username')
                password = request.POST.get('password')
                confirmPassword = request.POST.get('confirm_password')
                if password == confirmPassword and len(password)>=8:
                    if username not in usernames:
                        StaffInfo.objects.create(
                            first_name = request.POST.get('first_name'),
                            middle_name = request.POST.get('middle_name'),
                            last_name = request.POST.get('last_name'),
                            contact_number = request.POST.get('contact_number'),
                            email = request.POST.get('email'),
                            address = request.POST.get('address'),
                            username = request.POST.get('username'),
                            password = request.POST.get('password')
                            )
                        new_staff=User.objects.create_user(username , request.POST['email'], password)
                        new_staff.is_staff = True
                        new_staff.save()
                        return redirect('../')
                    else:
                        messages.warning(request, 'username has already been used.')
                else:
                    if len(password)<8:
                        messages.warning(request, 'Password length must be greater than 8 character.')
                    else:
                        messages.warning(request, 'Password Mismatch')
            else:
                form = StaffInfoForm(request.POST or None)
        content={
            'form':form
        }
    return render(request, 'addStaff.html',content)

def editStaffInformation_view(request, username):
    if  (not request.user.is_authenticated or request.user.is_staff == False):
        raise Http404
    elif request.user.is_authenticated:
        sign=0
        name= username
        obj= get_object_or_404(StaffInfo, username= name )
        user= User.objects.get(username=name)
        data={
            'first_name' : obj.first_name,
            'middle_name': obj.middle_name,
            'last_name': obj.last_name,
            'contact_number': obj.contact_number,
            'email': obj.email,
            'address': obj.address,
            'username': obj.username,
            'password': obj.password,
            'confirm_password':' '
        }
        #to change the username in every transactions if ever the customer edited his/her username
        items = Item.objects.all()
        transaction= []
        for item in items:
            if item.username== name:
                transaction.append(item.id)
        #we need to get all the users username so that we can check if the username already exited duplication is prohibited
        users = User.objects.all()
        usernames=[]
        for us in users:
            usernames.append(us.username)
        form = StaffInfoForm(request.POST or None,initial = data)
        if request.method =='POST':
            if form.is_valid():
                obj.first_name= request.POST.get('first_name')
                obj.middle_name= request.POST.get('middle_name')
                obj.last_name= request.POST.get('last_name')
                obj.contact_number= request.POST.get('contact_number')
                obj.address= request.POST.get('address')
                obj.save()
                #if the user change his/her username
                new = request.POST.get('username')
                if new!= obj.username:
                    if new not in usernames:
                        obj.username= request.POST.get('username')
                        obj.save()
                        user.username = new
                        user.save()
                        #change the username of customer's every transaction
                        for i in transaction:
                            laundry= Item.objects.get(id= i)
                            laundry.username= new
                            laundry.save()
                    else:
                        messages.warning(request, 'username has already been used.')
                #if the user change his/her email
                if request.POST.get('email')!= user.email:
                    obj.email= request.POST.get('email')
                    obj.save()
                    user.email= request.POST.get('email')
                    user.save()
                #if the user change his/her password
                new_pass= request.POST.get('password')
                old_pass= obj.password
                if new_pass != old_pass:
                    if len(new_pass)>=8 and new_pass == request.POST.get('confirm_password'):
                        obj.password= request.POST.get('password')
                        obj.save()
                        user.delete()
                        _new= User.objects.create_user(request.POST.get('username'), request.POST.get('email'), new_pass)
                        _new.is_staff= True
                        _new.save()
                        logout(request)
                        return redirect(f"../../../{user.username}")
                    elif len(new_pass)<8:
                        messages.warning(request, 'Password length must be greater than 8 character.')
                        sign=1
                    else:
                        messages.warning(request, 'Password Mismatch')
                        sign=1

                if sign!=1:
                    return redirect(f'../../../{user.username}/account')
                else:
                    return redirect(f'../../../{user.username}/account/edit')

            else:
                form = StaffInfoForm(request.POST or None,initial = data)
        context= {
            'form':form
        }
    return render(request, 'editStaffAccount.html', context)

def deleteStaffAccount_view(request, username):
    if  (not request.user.is_authenticated or request.user.is_staff == False):
        raise Http404
    elif request.user.is_authenticated:
        name = username
        StaffIn= get_object_or_404(StaffInfo, username= name)
        user= get_object_or_404(User, username= name)
        if request.method == 'POST':
            StaffIn.delete()
            user.delete()
            return redirect('../../../')
        context={
            "Staff": StaffIn
        }
    return render(request, 'deleteStaffAccount.html', context)

def incomeInformation_view(request, username):
    if  (not request.user.is_authenticated or request.user.is_staff == False):
        raise Http404
    elif request.user.is_authenticated:
        items = Item.objects.all()
        completed=[]
        totalIncome= 0
        for item in items:
            if item.complete == True:
                completed.append(item)
                totalIncome= totalIncome+ item.totalBill
        if request.method == 'POST':
            searchType= request.POST.get('incometype')
            if searchType == 'Yearly':
                try:
                    year = int(request.POST.get('year'))
                    return redirect(f'{year}/')
                except ValueError:
                    messages.warning(request, 'Invalid Input.')
            elif searchType == 'Monthly':
                try:
                    year = int(request.POST.get('year'))
                    month = int(request.POST.get('month'))
                    if month>12 or month<1:
                        raise ValueError
                    else:
                        return redirect(f'{year}/{month}/')
                except ValueError:
                    messages.warning(request, 'Invalid Input.')
            elif searchType == 'Daily':
                try:
                    year = int(request.POST.get('year'))
                    month = int(request.POST.get('month'))
                    day = int(request.POST.get('day'))
                    if month>12 or month<1 or day>31 or day<1:
                        raise ValueError
                    else:
                        return redirect(f'{year}/{month}/{day}/')
                except ValueError:
                    messages.warning(request, 'Invalid Input.')
            else:
                messages.warning(request, 'Invalid Input for Income type. ')

        completed.reverse()
        content={
            'all': completed,
            'totalIn': totalIncome,
            'object': request.user
        }
    return render(request, 'incomeInformation.html', content)

def yearlyIncome_view(request,username, year):
    if  (not request.user.is_authenticated or request.user.is_staff == False):
        raise Http404
    elif request.user.is_authenticated:
        items = Item.objects.all()
        completed=[]
        totalIncome= 0
        for item in items:
            if item.complete == True and item.date.year == year:
                completed.append(item)
                totalIncome= totalIncome + item.totalBill
        content ={
            'info': completed,
            'totalIn': totalIncome,
            'year': year
        }
    return render(request, 'yearlyIncome.html', content)


def monthlyIncome_view(request, username, year, month):
    if  (not request.user.is_authenticated or request.user.is_staff == False):
        raise Http404
    elif request.user.is_authenticated:
        items = Item.objects.all()
        completed=[]
        totalIncome= 0
        for item in items:
            if item.complete == True and item.date.year == year and item.date.month == month:
                completed.append(item)
                totalIncome= totalIncome + item.totalBill
        content ={
            'info': completed,
            'totalIn': totalIncome,
            'year': year,
            'month': calendar[month]
        }
    return render(request, 'monthlyIncome.html', content)

def dailyIncome_view(request, username, year, month, day):
    if  (not request.user.is_authenticated or request.user.is_staff == False):
        raise Http404
    elif request.user.is_authenticated:
        items = Item.objects.all()
        completed=[]
        totalIncome= 0
        for item in items:
            if item.complete == True and item.date.year == year and item.date.month == month and item.date.day == day:
                completed.append(item)
                totalIncome= totalIncome + item.totalBill
        content ={
            'info': completed,
            'totalIn': totalIncome,
            'year': year,
            'month': calendar[month],
            'day': day
        }
    return render(request, 'dailyIncome.html', content)

def changePrice(request, username):
    if  (not request.user.is_authenticated or request.user.is_staff == False):
        raise Http404
    elif request.user.is_authenticated:
        orig= get_object_or_404(Price, id=1 )
        foldData={
            "Fregular" : orig.FPr_regular,
            "Fdenims" : orig.FPr_jeans_maong,
            "FcurTableBed" : orig.FPr_curTableBed,
            "FcomfSlbagBla" : orig.FPr_comfSlbagBla,
            "FtoweLines" : orig.FPr_toweLines
        }
        pressData={
            "Pregular" : orig.PPr_regular,
            "Pdenims" : orig.PPr_jeans_maong,
            "PcurTableBed" : orig.PPr_curTableBed,
            "PcomfSlbagBla" : orig.PPr_comfSlbagBla,
            "PtoweLines" : orig.PPr_toweLines
        }
        fold= FoldPriceForm(request.POST or None,initial = foldData)
        press= PressPriceForm(request.POST or None,initial = pressData)
        if request.method== 'POST':
            if fold.is_valid() and press.is_valid():
                orig.FPr_regular = request.POST.get('Fregular')
                orig.FPr_jeans_maong = request.POST.get('Fdenims')
                orig.FPr_curTableBed = request.POST.get('FcurTableBed')
                orig.FPr_comfSlbagBla  = request.POST.get('FcomfSlbagBla')
                orig.FPr_toweLines = request.POST.get('FtoweLines')
                orig.PPr_regular = request.POST.get('Pregular')
                orig.PPr_jeans_maong = request.POST.get('Pdenims')
                orig.PPr_curTableBed = request.POST.get('PcurTableBed')
                orig.PPr_comfSlbagBla  = request.POST.get('PcomfSlbagBla')
                orig.PPr_toweLines = request.POST.get('PtoweLines')
                orig.save()
                return redirect('../')
            else:
                fold= FoldPriceForm(request.POST or None,initial = foldData)
                press= PressPriceForm(request.POST or None,initial = pressData)

        content={
            'foldform' : fold,
            'pressform' : press
        }
    return render(request, 'changePrice.html', content)

def prices_view(request, username):
    if  (not request.user.is_authenticated or request.user.is_staff == False):
        raise Http404
    elif request.user.is_authenticated:
        orig= get_object_or_404(Price, id=1 )
        content ={
            'price': orig,
            'object': request.user,
        }
    return render(request, 'staffViewPrices.html', content)
