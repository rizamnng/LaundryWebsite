from django.shortcuts import render, redirect, get_object_or_404
from clientInfo.models import ClientInfo
from Staff.models import Price
from .models import Item, Notification
from django.contrib import messages
from django.http import HttpResponseRedirect
from django.contrib.auth import logout
from clientInfo.forms import ClientInfoForm
from .forms import TransactionForm
from django.views.generic import DetailView
from django.utils.timezone import datetime
from django.contrib.auth.models import User
from django.http import HttpResponse, Http404
from django.contrib.auth.forms import UserCreationForm, AuthenticationForm
# Create your views here.

def accountHome_view(request, username):
    orig= get_object_or_404(Price, id=1 )
    if  (not request.user.is_authenticated) or (request.user.is_staff):
        return redirect('../login/')
    elif request.user.is_authenticated and username!=request.user.username:
        return HttpResponseRedirect(f'/{request.user}/')

    context={
        'object': request.user,
        'price': orig
        }
    return render(request, "home.html",context)

def logOut_view(request, username):
    if request.user.is_authenticated:
        logout(request)
    return redirect('../../../')

def booking_view(request, username):
    if  (not request.user.is_authenticated) or (request.user.is_staff):
        raise Http404
    elif request.user.is_authenticated:
        name = username
        customer= ClientInfo.objects.get( username= name)
        data ={
            'first_name': customer.first_name,
            'middle_name': customer.middle_name,
            'last_name': customer.last_name,
            'contact_number': customer.contact_number,
            'email': customer.email,
            'address': customer.address,
            'specific_address': customer.specific_address
        }
        form = TransactionForm(request.POST or None,initial = data)
        if request.method == 'POST':
            if form.is_valid():
                time_10= request.POST.get('time10')
                time_5= request.POST.get('time5')
                notes= request.POST.get('note')
                _type= request.POST.get('type')
                if time_10=="on" or time_5=="on":
                    if _type== 'Wash-Dry-Fold' or  _type== 'Wash-Dry-Press':
                        if time_10=='on' and time_5=="on":
                            get_time= '10-AM or 5-PM'
                        elif time_10=='on':
                            get_time= '10-AM'
                        else:
                            get_time= '5-PM'
                        Item.objects.create(
                            first_name = request.POST.get("first_name"),
                            middle_name = request.POST.get("middle_name"),
                            last_name = request.POST.get("last_name"),
                            contact_number = request.POST.get("contact_number"),
                            email = request.POST.get("email"),
                            address = request.POST.get("address"),
                            specific_address = request.POST.get("specific_address"),
                            type = _type,
                            regular = 0,
                            jeans_maong = 0,
                            curTableBed = 0,
                            comfSlbagBla = 0,
                            toweLines = 0,
                            getTime = get_time,
                            customerNote = notes,
                            complete = False,
                            totalBill = 0,
                            username = name,
                            delivered = False
                        )
                        return redirect('booked/')
                    else:
                        messages.warning(request, 'Invalid Input for Laundry type. ')
                else:
                    messages.warning(request, 'Invalid Input for Pick-up time. ')
            else:
                form = TransactionForm(request.POST or None,initial = data)
        content={
            'form' : form
        }
    return render(request, 'booking.html', content )

def booked_transactions_view(request, username):
    if  (not request.user.is_authenticated) or (request.user.is_staff):
        raise Http404
    elif request.user.is_authenticated:

        name= username
        obj= Item.objects.all()
        for data in obj:
            if data.username == username:
                info= data
        context={
            'customer':info
        }
    return render(request, 'booked_transactions.html', context)

def editInformation_view(request, username):
    if  (not request.user.is_authenticated) or (request.user.is_staff):
        raise Http404
    elif request.user.is_authenticated:
        sign=0
        name= username
        obj= get_object_or_404(ClientInfo, username= name )
        user= User.objects.get(username=name)
        data={
            'first_name' : obj.first_name,
            'middle_name': obj.middle_name,
            'last_name': obj.last_name,
            'contact_number': obj.contact_number,
            'email': obj.email,
            'address': obj.address,
            'specific_address': obj.specific_address,
            'username': obj.username,
            'password': obj.password,
            'confirmPassword':' '
        }
        #to change the username in every transactions if ever the customer edited his/her username
        items = Item.objects.all()
        transaction= []
        for item in items:
            if item.username== name:
                transaction.append(item.id)
        #we need to get all the users username so that we can check if the username already exited duplication is prohibited
        users = User.objects.all()
        usernames=[]
        for us in users:
            usernames.append(us.username)
        form = ClientInfoForm(request.POST or None,initial = data)
        if request.method =='POST':
            if form.is_valid():
                obj.first_name= request.POST.get('first_name')
                obj.middle_name= request.POST.get('middle_name')
                obj.last_name= request.POST.get('last_name')
                obj.contact_number= request.POST.get('contact_number')
                obj.address= request.POST.get('address')
                obj.specific_address= request.POST.get('specific_address')
                obj.save()
                #if the user change his/her username
                new = request.POST.get('username')
                if new!= obj.username:
                    if new not in usernames:
                        obj.username= request.POST.get('username')
                        obj.save()
                        user.username = new
                        user.save()
                        #change the username of customer's every transaction
                        for i in transaction:
                            laundry= Item.objects.get(id= i)
                            laundry.username= new
                            laundry.save()
                    else:
                        messages.warning(request, 'username has already been used.')
                #if the user change his/her email
                if request.POST.get('email')!= user.email:
                    obj.email= request.POST.get('email')
                    obj.save()
                    user.email= request.POST.get('email')
                    user.save()
                #if the user change his/her password
                new_pass= request.POST.get('password')
                old_pass= obj.password
                print(new_pass, old_pass)
                if new_pass != old_pass:
                    if len(new_pass)>=8 and new_pass == request.POST.get('confirmPassword'):
                        obj.password= request.POST.get('password')
                        obj.save()
                        user.delete()
                        User.objects.create_user(request.POST.get('username'), request.POST.get('email'), new_pass)
                        logout(request)
                        return redirect(f"../../../{user.username}")
                    elif len(new_pass)<8:
                        messages.warning(request, 'Password length must be greater than 8 character.')
                        sign=1
                    else:
                        messages.warning(request, 'Password Mismatch')
                        sign=1

                if sign!=1:
                    return redirect(f'../../../{user.username}/account')
                else:
                    return redirect(f'../../../{user.username}/account/edit')

            else:
                form = ClientInfoForm(request.POST or None,initial = data)
        context= {
            'form':form
        }
    return render(request, 'editAccount.html', context)

def currentTransactions_view(request, username):
    if  (not request.user.is_authenticated) or (request.user.is_staff):
        raise Http404
    elif request.user.is_authenticated:
        name= username
        obj= Item.objects.all()
        lists=[]
        for data in obj:
            if data.username == username:
                lists.append(data)
        lists.reverse()
        context={
            'info': lists
        }
    return render(request, 'currentTransactionds.html', context)

class ItemDetail_view(DetailView):
    template_name= "transactionDetails.html"
    queryset= Item.objects.all()

    def get(self, request, *args, **kwargs):
        if  (not request.user.is_authenticated) or (request.user.is_staff):
            raise Http404
        return super().get(request, *args, **kwargs)

    def get_object(self):
        id_= self.kwargs.get("id")
        return get_object_or_404(Item, id=id_)


class AccountDetail_view(DetailView):
    template_name= 'account.html'
    queryset= ClientInfo.objects.all()

    def get(self, request, *args, **kwargs):
        if  (not request.user.is_authenticated) or (request.user.is_staff):
            raise Http404
        return super().get(request, *args, **kwargs)

    def get_object(self):
        id_= self.kwargs.get('username')
        return get_object_or_404(ClientInfo, username=id_)




def deleteAccount_view(request, username):
    if  (not request.user.is_authenticated) or (request.user.is_staff):
        raise Http404
    elif request.user.is_authenticated:
        name = username
        clientIn= get_object_or_404(ClientInfo, username= name)
        user= get_object_or_404(User, username= name)
        if request.method == 'POST':
            clientIn.delete()
            user.delete()
            return redirect('../../../')
        context={
            "client": clientIn
        }
    return render(request, 'deleteAccount.html', context)

def notification_view(request, username):
    if  (not request.user.is_authenticated) or (request.user.is_staff):
        raise Http404
    elif request.user.is_authenticated:
        name =username
        notifications = Notification.objects.all()
        notify=[]
        for note in notifications:
            if note.username == name and note.read == False:
                notify.append(note)
        notify.reverse()
        content={
            'info':notify
        }
    return render(request, 'notification.html', content)

def notification_details(request, username, id):
    if  (not request.user.is_authenticated) or (request.user.is_staff):
        raise Http404
    elif request.user.is_authenticated:
        notifications = Notification.objects.get(id=id)
        try:
            item =Item.objects.get(id=notifications.laundry_id)
        except:
            return redirect(f'../denied/{id}')
        if request.method == 'POST':
            notifications.read=True
            notifications.save()
            return redirect('../')
        content={
            'object': item
        }
    return render(request, 'notificationDetails.html', content)

def notification_denied(request, username, id ):
    if  (not request.user.is_authenticated) or (request.user.is_staff):
        raise Http404
    elif request.user.is_authenticated:
        notifications = Notification.objects.get(id=id)
        if request.method == 'POST':
            notifications.read=True
            notifications.save()
            return redirect('../../')
        content={
            'notif': notifications
        }
    return render(request, 'deniedLaundry.html', content)


def about_us_view(request, username):
    if  (not request.user.is_authenticated) or (request.user.is_staff):
        raise Http404
    elif request.user.is_authenticated:
        return render(request, 'aboutus.html', {})

def services_view(request, username):
    if  (not request.user.is_authenticated) or (request.user.is_staff):
        raise Http404
    elif request.user.is_authenticated:
        return render(request, 'services.html', {})
