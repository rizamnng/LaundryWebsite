from django.urls import path, include
from . import views

urlpatterns = [
    path("", views.accountHome_view, name="accountHome"),
    path("logout/", views.logOut_view, name= "logout"),
    path("book/", views.booking_view, name="book"),
    path('notification/', views.notification_view, name='notification'),
    path('notification/<int:id>/', views.notification_details, name='notificationdetails'),
    path('book/booked/', views.booked_transactions_view, name="booked"),
    path('transactions/', include('transactions.transactionDetailUrl')),
    path('account/', include('transactions.accountUrls')),
    path('about-us/', views.about_us_view, name='about-us'),
    path('services/', views.services_view, name='services'),
    path('notification/denied/<int:id>/', views.notification_denied, name='denied'),
]
