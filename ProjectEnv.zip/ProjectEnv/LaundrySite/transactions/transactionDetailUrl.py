from django.urls import path, include
from . import views

urlpatterns = [
    path('', views.currentTransactions_view, name="current-transactions"),
    path("<int:id>/", views.ItemDetail_view.as_view(), name='transaction-detail')
]
