from django.urls import path, include
from . import views
from .views import AccountDetail_view

urlpatterns = [
    path("", AccountDetail_view.as_view(), name='accountView'),
    path("edit/", views.editInformation_view, name='edit'),
    path('delete/', views.deleteAccount_view, name='delete')
]
