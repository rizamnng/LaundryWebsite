from django.db import models

# Create your models here.

class Item(models.Model):
    first_name = models.CharField(max_length=120, default=" ")
    middle_name = models.CharField(max_length=120, default=" ")
    last_name = models.CharField(max_length=120, default=" ")
    contact_number = models.CharField(max_length=12, default=" ")
    email = models.EmailField(max_length=120, default=" ")
    address = models.CharField(max_length=200, default=" ")
    specific_address = models.TextField( default=" ")
    type= models.CharField(max_length=120)
    regular = models.DecimalField(max_digits= 1000, decimal_places= 2)
    jeans_maong = models.DecimalField(max_digits= 1000, decimal_places= 2)
    curTableBed = models.DecimalField(max_digits= 1000, decimal_places= 2)
    comfSlbagBla = models.DecimalField(max_digits= 1000, decimal_places= 2)
    toweLines = models.DecimalField(max_digits= 1000, decimal_places= 2)
    getTime = models.CharField(max_length=20 )
    customerNote = models.TextField(default= '')
    complete = models.BooleanField(default= False)
    totalBill=models.DecimalField(max_digits= 100000000000, decimal_places= 2, default= 0)
    username = models.CharField(max_length=120)
    delivered = models.BooleanField(default= False)
    date = models.DateTimeField(auto_now_add=True)


class Notification(models.Model):
    laundry_id= models.CharField(max_length=120, default=" ")
    username = models.CharField(max_length=120)
    message= models.CharField(max_length=200, default=" ")
    incharge_staff= models.CharField(max_length=200, default=" ")
    reason= models.CharField(max_length=120, default=" ")
    read= models.BooleanField(default= False)
