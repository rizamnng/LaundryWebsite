from django import forms
from .models import ClientInfo

class ClientInfoForm(forms.Form):
    first_name = forms.CharField(label='First Name', required = True, widget=forms.TextInput(attrs={'class': 'form-control'}))
    middle_name = forms.CharField(label='Middle Name',required = False, widget=forms.TextInput(attrs={'class': 'form-control'}))
    last_name = forms.CharField(label='Last Name',required = True, widget=forms.TextInput(attrs={'class': 'form-control'}))
    contact_number = forms.CharField(label='Contact Number',required = True, widget=forms.TextInput(attrs={'class': 'form-control'}))
    email = forms.EmailField(required = True, widget=forms.TextInput(attrs={'class': 'form-control'}))
    address = forms.CharField(required = True, widget=forms.TextInput(attrs={'class': 'form-control'}))
    specific_address = forms.CharField(label='Specific Address',required = True, widget=forms.TextInput(attrs={'class': 'form-control'}))
    username= forms.CharField(required = True, widget=forms.TextInput(attrs={'class': 'form-control'}))
    password = forms.CharField(widget=forms.PasswordInput(attrs={'class': 'form-control'}), required = True)
    confirmPassword = forms.CharField(label='Confirm Password',widget=forms.PasswordInput(attrs={'class': 'form-control'}), required = True)

class logInForm(forms.Form):
    username= forms.CharField()
    password = forms.CharField(widget=forms.PasswordInput())
