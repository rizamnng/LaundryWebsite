from django.apps import AppConfig


class ClientinfoConfig(AppConfig):
    name = 'clientInfo'
