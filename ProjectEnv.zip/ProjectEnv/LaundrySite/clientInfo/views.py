from django.shortcuts import render, redirect, get_object_or_404
from django.contrib.auth.models import User
from django.http import HttpResponse
from django import forms
from django.contrib.auth.forms import UserCreationForm, AuthenticationForm
from django.contrib import messages
from django. contrib. auth import authenticate, login
from django.shortcuts import redirect
from .models import ClientInfo
from .forms import logInForm, ClientInfoForm
from Staff.models import Price

# Create your views here.

def home_view(request,*args, **kwargs):
    orig= get_object_or_404(Price, id=1 )
    context={
            'object': request.user,
            'price': orig
            }
    return render(request, "welcomePage.html",context)

def signup_view(request, *args, **kwargs ):
    users = User.objects.all()
    usernames=[]
    for obj in users:
        usernames.append(obj.username)
    form = ClientInfoForm(request.POST or None)
    if request.method == 'POST':
        form = ClientInfoForm(request.POST)
        if form.is_valid():
            username = request.POST.get('username')
            password = request.POST.get('password')
            confirmPassword = request.POST.get('confirmPassword')
            if password == confirmPassword and len(password)>=8:
                if username not in usernames:
                    ClientInfo.objects.create(
                        first_name = request.POST.get('first_name'),
                        middle_name = request.POST.get('middle_name'),
                        last_name = request.POST.get('last_name'),
                        contact_number = request.POST.get('contact_number'),
                        email = request.POST.get('email'),
                        address = request.POST.get('address'),
                        specific_address= request.POST.get('specific_address'),
                        username = request.POST.get('username'),
                        password = request.POST.get('password')
                        )
                    User.objects.create_user(username , request.POST['email'], password)
                    customer = authenticate(username=request.POST['username'], password=request.POST['password'])
                    name=request.POST['username']
                    if customer is not None:
                        login(request, customer)
                        return redirect(f'../{name}')
                    else:
                        return redirect('../')
                else:
                    messages.warning(request, 'username has already been used.')
            else:
                if len(password)<8:
                    messages.warning(request, 'Password length must be greater than 8 character.')
                else:
                    messages.warning(request, 'Password Mismatch')
        else:
            form = ClientInfoForm(request.POST or None)
    content={
        'form':form
    }

    return render(request, 'signUp.html',content)

def login_request(request):
    form = AuthenticationForm()
    if request.method == 'POST':
        form = AuthenticationForm(request=request, data=request.POST)
        if form.is_valid():
            username = form.cleaned_data.get('username')
            password = form.cleaned_data.get('password')
            user = authenticate(username=username, password=password)
            if user is not None :
                login(request, user)
                return redirect(f'../{username}')


    return render(request = request,
                    template_name = "login.html",
                    context={"form":form})
