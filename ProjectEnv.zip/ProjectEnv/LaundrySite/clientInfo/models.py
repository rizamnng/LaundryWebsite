from django.db import models

# Create your models here.
class ClientInfo(models.Model):
    first_name = models.CharField(max_length=120)
    middle_name = models.CharField(max_length=120)
    last_name = models.CharField(max_length=120)
    contact_number = models.CharField(max_length=12)
    email = models.EmailField(max_length=120)
    address = models.CharField(max_length=200)
    specific_address = models.TextField()
    username = models.CharField(max_length=120)
    password = models.CharField(max_length=120)
